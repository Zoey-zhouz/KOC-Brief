import React from 'react';
import { Icons } from '../../src/assets/icons';

interface SectionTechProps {
  labels: { [key: string]: string };
  isOnboarding?: boolean;
  onBack: () => void;
  onNext: () => void;
}

const SectionTech: React.FC<SectionTechProps> = ({ labels, isOnboarding, onBack, onNext }) => {
  return (
    <div className="max-w-7xl mx-auto px-6 py-12 md:py-20 animate-slide-up">
      <div className="flex justify-between items-center mb-12 md:mb-16">
        <button onClick={onBack} className="flex items-center gap-2 text-brand-primary/40 hover:text-brand-primary font-bold transition-colors uppercase text-[10px] md:text-xs tracking-widest">
          <Icons.ChevronDown className="rotate-90" /> {labels.home}
        </button>
      </div>

      <div className="mb-16 md:mb-24">
        <p className="text-brand-primary/40 text-[10px] md:text-xs font-bold uppercase tracking-widest mb-6">In this section: Our advanced techniques and sustainable materials.</p>
        <h1 className="text-4xl md:text-8xl font-serif text-brand-primary mb-8 md:mb-10 tracking-tighter leading-tight">Technology & Materials</h1>
      </div>

      <div className="bg-brand-beige rounded-none p-10 md:p-32 text-brand-primary relative overflow-hidden shadow-inner border border-brand-primary/5">
        <div className="absolute top-0 right-0 w-[400px] md:w-[700px] h-[400px] md:h-[700px] bg-brand-taupe rounded-full blur-[100px] md:blur-[150px] -mr-40 md:-mr-96 -mt-40 md:-mt-96 opacity-50"></div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-24 relative z-10 max-w-6xl mx-auto">
          <div className="space-y-8 md:space-y-14">
            <div className="w-full aspect-video overflow-hidden rounded-xl shadow-2xl border border-brand-primary/10">
              <img src="https://lh3.googleusercontent.com/d/1GI14vx-9YVHdhPJz05SmJEf1OLQccbGj" className="w-full h-full object-cover" alt="Arch Support Insoles" referrerPolicy="no-referrer" />
            </div>
            <h3 className="text-2xl md:text-4xl font-serif tracking-tight border-b border-brand-primary/10 pb-4 md:pb-6">Arch Support Insoles</h3>
            <p className="text-slate-600 text-xl md:text-2xl font-light leading-relaxed italic">
              Our specially designed insoles provide reinforced arch and forefoot support to reduce foot fatigue. We will continue to refine our technology and materials based on customer feedback.
            </p>
          </div>
          
          <div className="space-y-8 md:space-y-14">
            <div className="w-full aspect-video overflow-hidden rounded-xl shadow-2xl border border-brand-primary/10">
              <img src="https://lh3.googleusercontent.com/d/1qE9r8k3YdxFn66FbkqMGZFcOOzAy2U_C" className="w-full h-full object-cover" alt="Air Weave Fabric" referrerPolicy="no-referrer" />
            </div>
            <h3 className="text-2xl md:text-4xl font-serif tracking-tight border-b border-brand-primary/10 pb-4 md:pb-6">Air Weave Fabric</h3>
            <p className="text-slate-600 text-xl md:text-2xl font-light leading-relaxed italic">
              To address issues such as bunions and bursitis, we integrate elastic yarn and advanced 3D knit technology into our shoes, creating flexible support that adapts to your movement.
            </p>
          </div>
        </div>
      </div>

      <div className="flex justify-center mt-20">
        <button onClick={onNext} className="bg-brand-primary text-white px-16 py-6 rounded-full text-xs font-black uppercase tracking-[0.4em] hover:bg-brand-secondary transition-all shadow-2xl">
          Next Step <i className="fas fa-arrow-right ml-3"></i>
        </button>
      </div>
    </div>
  );
};

export default SectionTech;
