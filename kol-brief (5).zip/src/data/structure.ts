export const YT_STRUCTURE_CONTENT = {
  intro: "Based on our YouTube collaboration experience, the following video structure is recommended for long-form or integrated content.",
  steps: [
    { 
      title: "Hook", 
      desc: "Catch attention in the first 10-15s for YouTube. A strong hook is essential for viewer retention.", 
      examples: [
        { url: "https://res.cloudinary.com/dqdisi2yp/image/upload/v1772605384/Brief-%20total/Brief-photos/thumbnail_-1_zpoqdg.jpg", id: "@kseni_wolter", title: "1. Hook Thumbnail" },
        { url: "https://res.cloudinary.com/dqdisi2yp/image/upload/v1772605384/Brief-%20total/Brief-photos/thumbnail_-2_c6sgep.jpg", id: "@euphoria_el_", title: "2. Hook Thumbnail" },
        { url: "https://res.cloudinary.com/dqdisi2yp/image/upload/v1772605383/Brief-%20total/Brief-photos/thumbnail_-3_ujwcsf.jpg", id: "@reginemorales20", title: "3. Hook Thumbnail" }
      ],
      hookIntro: {
        intro: "For YouTube, hooks can be slightly longer but must be even more compelling to prevent viewers from clicking away.",
        types: [
          {
            title: "The Question Hook",
            desc: "Start with a question that your video will answer.",
            icon: "fa-question",
            videoExamples: ["https://picsum.photos/seed/yt-q1/400/711"],
            author: "@yt_expert"
          },
          {
            title: "The Result Hook",
            desc: "Show the final result or the best part of the video first.",
            icon: "fa-trophy",
            videoExamples: ["https://picsum.photos/seed/yt-r1/400/711"],
            author: "@yt_expert"
          }
        ]
      }
    },
    { 
      title: "Product Information", 
      desc: "Detailed introduction of the product features and benefits.", 
      examples: ["https://picsum.photos/seed/yt-info/400/711"] 
    },
    { 
      title: "Brand VI", 
      desc: "Incorporate brand visual identity elements naturally.", 
      examples: ["https://picsum.photos/seed/yt-vi/400/711"] 
    },
    { 
      title: "Excellent Video Cases", 
      desc: "Reviewing successful examples of similar content.", 
      examples: ["https://picsum.photos/seed/yt-cases/400/711"] 
    },
    { 
      title: "Technology & Materials", 
      desc: "Deep dive into the comfort technology and high-quality materials.", 
      examples: ["https://picsum.photos/seed/yt-tech/400/711"] 
    },
    { 
      title: "Brand Story", 
      desc: "Sharing the mission and vision of COSY ISLAND.", 
      examples: ["https://picsum.photos/seed/yt-story/400/711"] 
    }
  ],
  reminder1: { title: "", points: [], images: [] },
  reminder2: { title: "", desc: "", images: [] }
};

export const STRUCTURE_CONTENT = {
  intro: "Based on our past collaboration experience, the following video structure has proven to be the most effective for promoting footwear on Instagram.",
  steps: [
    { 
      title: "Hook", 
      desc: "Catch attention in 3-5s. A hook is crucial for performance and platform algorithms.", 
      examples: [
        { url: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772612922/_moriahhgrace__2025-08-20T151106.000Z_yeuqbq.mp4", id: "@moriahhgrace", title: "1. Theme Hook" },
        { url: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772613296/Text_-HOOK_mzclaj.mp4", id: "@mariesbazaar", title: "2. Text Hook" },
        { url: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772612920/_ninuki19__2025-08-05T172320.000Z_jygosn.mp4", id: "@lashify", title: "3. Pattern interrupt Hook" },
        { url: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772605341/Brief-%20total/HOOK/Hook-Creative-3_melvelinalmonte_rf7y5b.mp4", id: "@melvelinalmonte", title: "4. Trend Hook" }
      ],
      hookIntro: {
        intro: "A hook is used in the first 3-5 seconds of your video to grab and retain viewer attention, signaling to the platform’s algorithm that your content is high quality. A strong hook is crucial for performance.",
        types: [
          {
            title: "Hook-Title",
            desc: "Videos with interesting titles can arouse the curiosity of viewers. When viewers read the title, they will stay on the page, thus greatly increasing the 3-second completion rate of the video.",
            examples: [
              "Asking questions: Why women always have to choose between beauty or comfort?",
              "Raising common dilemmas: Cute heels that kill my feet? Been there, done that.",
              "Opening with a story: Last week, I walked 8 hours in these heels… and didn’t feel a thing.",
              "Surprising tone: Warning: You might run in these heels. Comfort is real."
            ],
            icon: "fa-heading",
            videoExamples: [
              "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772612922/_moriahhgrace__2025-08-20T151106.000Z_yeuqbq.mp4",
              "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772613296/Text_-HOOK_mzclaj.mp4",
              "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772612920/_ninuki19__2025-08-05T172320.000Z_jygosn.mp4"
            ],
            author: "@moriahhgrace"
          },
          {
            title: "Hook-Creative",
            desc: "Trending creative Editing, Challenge or Story make your video more interesting.",
            icon: "fa-magic",
            videoExamples: [
              "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772612920/_ninuki19__2025-08-05T172320.000Z_jygosn.mp4",
              "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772605341/Brief-%20total/HOOK/Hook-Creative-3_melvelinalmonte_rf7y5b.mp4",
              "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772612922/_moriahhgrace__2025-08-20T151106.000Z_yeuqbq.mp4"
            ],
            author: "@lashify"
          },
          {
            title: "Visual impact",
            desc: "Unfold selling points with visual impact to capture audience’s attention.",
            icon: "fa-eye",
            videoExamples: [
              "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772613296/Text_-HOOK_mzclaj.mp4",
              "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772612922/_moriahhgrace__2025-08-20T151106.000Z_yeuqbq.mp4",
              "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772605341/Brief-%20total/HOOK/Hook-Creative-3_melvelinalmonte_rf7y5b.mp4"
            ],
            author: "@mariesbazaar"
          }
        ]
      }
    },
    { 
      title: "Product Reveal", 
      desc: "Showcase the product in an aesthetic way. Please refer to the Safe Zone guide: https://drive.google.com/file/d/1oc3n_kNKDvOXoU9SoVgPCnB1rk_kExOW/view?usp=drive_link", 
      examples: [
        "https://res.cloudinary.com/dqdisi2yp/image/upload/v1772605382/Brief-%20total/Brief-photos/Safe_zone-1_u6juxs.jpg", 
        "https://res.cloudinary.com/dqdisi2yp/image/upload/v1772605368/Brief-%20total/Brief-photos/Safe_zone-2_g7y4w1.jpg",
        "https://res.cloudinary.com/dqdisi2yp/image/upload/v1772605367/Brief-%20total/Brief-photos/Safe_zone-3_q8mrtz.jpg"
      ] 
    },
    { 
      title: "Feature Showcase", 
      desc: "Showcase 1-2 product features that solve the issues you mention in the hook.", 
      examples: [
        { url: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772605366/Brief-%20total/feature%20showcase/2_5._Feature_Showcase-1_kenzii_04_rjqh7t.mp4", id: "@kenzii_04", title: "Soft and comfy uppers and soles" },
        { url: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772605367/Brief-%20total/feature%20showcase/2_5._Feature_Showcase-2_naty_vau_rlhbyj.mp4", id: "@naty_vau", title: "Ergonomic & arch support cushion" },
        { url: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772605366/Brief-%20total/feature%20showcase/2_5._Feature_Showcase-3_deliriarose_hlxufs.mp4", id: "@deliriarose", title: "Stable heels for steady steps" },
        { url: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772605366/Brief-%20total/feature%20showcase/2_5._Feature_Showcase-4_emily.e.young_rotdyw.mp4", id: "@emily.e.young", title: "Slingback straps that stay put" },
        { url: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772605367/Brief-%20total/feature%20showcase/2_5._Feature_Showcase-5_cathefriedrich_qbzlnc.mp4", id: "@cathefriedrich", title: "Comfy like sneakers+quality check+stable heels" },
        { url: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772605365/Brief-%20total/feature%20showcase/2_5._Feature_Showcase-6_trendswithbren_mnwfm0.mp4", id: "@trendswithbren", title: "Textured rubber sole for slip resistance" },
        { url: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772605366/Brief-%20total/feature%20showcase/2_5._Feature_Showcase-7_lidiyabairon_yokpuq.mp4", id: "@lidiyabairon", title: "Multi-color choices" },
        { url: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772605367/Brief-%20total/feature%20showcase/2_5._Feature_Showcase-8_kellyn_mcmullan_wz6pph.mp4", id: "@kellyn_mcmullan", title: "Flared heels to prevent getting stuck in cracks" }
      ] 
    },
    { 
      title: "Styling", 
      desc: "Share the styling inspo to your audience.", 
      examples: [
        { url: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772605348/Brief-%20total/Structure/Styling1__ayagonz__2025-02-12T153022.000Z_fzgh32.mp4", id: "@_ayagonz", title: "Versatile styling for one scenario" },
        { url: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772605349/Brief-%20total/Structure/Styling2_shanndetrick__2025-04-01T215534.000Z_nld9xu.mp4", id: "@shanndetrick", title: "Versatile styling for multiple scenarios" }
      ] 
    },
    { 
      title: "Feature Showcase", 
      desc: "Please refer to the cases in 3. Feature Showcase. Beside the features you have mentioned, surprise your audience with “what’s more!”", 
      examples: [] 
    },
    { 
      title: "Call to Action", 
      desc: "Clearly guide your audience on how to purchase. Mention the link in bio, use clear verbal cues like 'Check out the link in my profile', and ensure the brand name COSY ISLAND is clearly visible or mentioned.", 
      examples: [] 
    },
    { 
      title: "Trendy Background Music", 
      desc: "Music selection depends on your shooting style. For rhythm-driven visual presentations, use data-backed music styles with fast tempo and strong beats.", 
      musicTypes: [
        {
          title: "Rhythm-Driven Visuals",
          desc: "If your shooting style is not voice-over but rather a more rhythm-driven visual presentation, here are some data-backed music styles that resonate well with our audience, provided for your reference.",
          examples: [
            { url: "https://picsum.photos/seed/music1/400/711", id: "@tamara_atzenwiler", title: "1. Intro" },
            { url: "https://picsum.photos/seed/music2/400/711", id: "@chimi.blog", title: "2. Classic" },
            { url: "https://picsum.photos/seed/music3/400/711", id: "@redlipsredbottoms", title: "3. MESSY X DREAMS" },
            { url: "https://picsum.photos/seed/music4/400/711", id: "@naomiijw", title: "4. I Loved Another Woman" }
          ]
        },
        {
          title: "High-Energy Tempo",
          desc: "The common feature of these music styles is their fast tempo, strong beats, and rhythmic energy, which tend to capture viewers’ attention. You can search for keywords like “EDM,” “Techno,” “Trance,” or “R&B.” to find similar tracks if you want.",
          examples: []
        }
      ],
      examples: [] 
    }
  ],
  reminder1: { title: "", points: [], images: [] },
  reminder2: { title: "", desc: "", images: [] }
};
