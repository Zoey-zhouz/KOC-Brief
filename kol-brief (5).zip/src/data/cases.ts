export const YT_INSPIRATION_CATEGORIES = [
  {
    title: "YouTube Review Style",
    desc: "In-depth reviews and unboxing experiences.",
    items: [
      { id: "yt_1", videoUrl: "https://picsum.photos/seed/yt-review1/400/711", description: "Comprehensive review with focus on comfort technology." },
      { id: "yt_2", videoUrl: "https://picsum.photos/seed/yt-review2/400/711", description: "Unboxing and first impressions for long-form content." }
    ]
  },
  {
    title: "YouTube Styling Guide",
    desc: "Longer styling videos and lookbooks.",
    items: [
      { id: "yt_3", videoUrl: "https://picsum.photos/seed/yt-styling1/400/711", description: "Seasonal lookbook featuring multiple outfits." },
      { id: "yt_4", videoUrl: "https://picsum.photos/seed/yt-styling2/400/711", description: "How to style high heels for different occasions." }
    ]
  }
];

export const INSPIRATION_CATEGORIES = [
  {
    title: "Trends that fit our product",
    desc: "Recent hot trends related to shoes or outfits.",
    items: [
      { id: "@saramahayri", videoUrl: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772611242/Trend_1-Feet_POV_GRWM-saramahayri__2026-02-26T102100.000Z_kbbw7g.mp4", description: "Feet POV GRWM" },
      { id: "@evajan.x", videoUrl: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772611243/Trend_2-rapid_outfit_check-evajan.x__2025-08-19T144903.000Z_gzvjew.mp4", description: "Rapid outfit check" },
      { id: "@jessideoliveira", videoUrl: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772611249/Trend_3-_I_fell_but_I_saved_my_...-jessideoliveira__2026-02-24T172107.000Z_vyufxg.mp4", description: "I fell but I saved my..." },
      { id: "@katyaklema", videoUrl: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772611245/Trend_4-colorful_detail_frames-katyaklema__2026-02-02T180741.000Z_7_guvbru.mp4", description: "Colorful detail frames" }
    ]
  },
  {
    title: "Editing tutorial",
    desc: "Popular editing tutorials suitable for IG.",
    items: [
      { id: "@stevenwommack", videoUrl: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772611348/Tutorial-trend_2-stevenwommack__2026-02-23T141032.000Z_lzixuh.mp4", description: "Tutorial trend 2" },
      { id: "@stevenwommack", videoUrl: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772611248/Tutorial-ai%E5%B0%8F%E4%BA%BA%E6%8D%A2%E8%A3%85-stevenwommack__2026-01-26T134821.000Z_1_hmlksn.mp4", description: "Tutorial AI outfit change" },
      { id: "@stevenwommack", videoUrl: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772611246/Tutorial-AI_transform_location-stevenwommack__2026-01-28T190058.000Z_vdcjgf.mp4", description: "Tutorial AI transform location" },
      { id: "@stevenwommack", videoUrl: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772611249/Tutorial-split_screen-stevenwommack__2026-01-24T111206.000Z_gfwnln.mp4", description: "Split screen tutorial" },
      { id: "@stevenwommack", videoUrl: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772611253/Tutorial%E6%95%99%E7%A8%8B-trend_4__2026-02-06T162457.000Z_gtptqu.mp4", description: "Tutorial trend 4" }
    ]
  },
  {
    title: "AIGC Cases",
    desc: "Showcasing our influencer content.",
    items: [
      { id: "@lanaforgeau", videoUrl: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772611908/AIGC-1_lanaforgeau__2026-02-27T160419.000Z_w6pxbt.mp4", description: "AIGC Case 1" },
      { id: "@paleshnyk.ai", videoUrl: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772611910/AIGC-2_paleshnyk.ai__2026-02-10T190105.000Z_w7lgwa.mp4", description: "AIGC Case 2" },
      { id: "@paleshnyk.ai", videoUrl: "https://res.cloudinary.com/dqdisi2yp/video/upload/v1772611916/AIGC-3_paleshnyk.ai__2026-02-14T193028.000Z_fejbw1.mp4", description: "AIGC Case 3" }
    ]
  }
];

export const DEFAULT_CASES = INSPIRATION_CATEGORIES[0].items.map(item => ({
  title: "Community Case",
  author: item.id,
  description: "Inspiration for your content.",
  videoUrl: item.videoUrl
}));
