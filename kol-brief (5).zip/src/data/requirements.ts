export const COMMON_REQUIREMENTS = {
  ig: {
    reelReqs: [
      { text: "Send us a preview before posting (CRITICAL)", status: 'must' as const },
      { text: "Feature only the assigned product", status: 'must' as const },
      { text: "English voiceover and subtitles", status: 'must' as const },
      { text: "Tag and mention @COSYISLAND_OFFICIAL", status: 'must' as const },
      { text: "Mention other brands", status: 'mustnt' as const },
      { text: "Inaccurate product color/shape", status: 'mustnt' as const }
    ],
    multiColorReelReqs: [
      { text: "Send us a preview before posting (CRITICAL)", status: 'must' as const },
      { text: "Show all colors at the beginning", status: 'must' as const },
      { text: "Use hot-selling colors to show shoe details", status: 'must' as const },
      { text: "Feature only the assigned product", status: 'must' as const },
      { text: "English voiceover and subtitles", status: 'must' as const },
      { text: "Tag and mention @COSYISLAND_OFFICIAL", status: 'must' as const },
      { text: "Mention other brands", status: 'mustnt' as const },
      { text: "Inaccurate product color/shape", status: 'mustnt' as const }
    ],
    carouselReqs: [
      { text: "Show assigned product clearly", status: 'must' as const },
      { text: "English captions first", status: 'must' as const },
      { text: "3 to 8 high-quality photos", status: 'must' as const },
      { text: "Competitor brand tags", status: 'mustnt' as const },
      { text: "Blurry or low-light shots", status: 'mustnt' as const }
    ],
    captionReqs: {
      ad: "Short: #ad at end. Long: #ad at start.",
      mentions: ["@cosyisland_official", "#cosyislanders", "#comfyheels"],
      exclusivity: "No competitor mentions.",
      direction: "Snappy or Informative."
    }
  },
  yt: {
    dedicated: [
      { text: "Whole video focused on Cosy Island", status: 'must' as const },
      { text: "Show product unboxing and close-ups", status: 'must' as const },
      { text: "Comparison with traditional painful heels", status: 'must' as const },
      { text: "Low audio quality", status: 'mustnt' as const }
    ],
    integrated: [
      { text: "60-90 seconds organic integration", status: 'must' as const },
      { text: "Natural transition from main topic", status: 'must' as const },
      { text: "Hidden or unclear sponsorship disclosure", status: 'mustnt' as const }
    ],
    captionReqs: {
      links: "cosyisland.co",
      tags: ["#cosyisland", "#highheelcomfort"]
    }
  }
};
